﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AutoNoma
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            this.RegFormBoxPassword.AutoSize = false;
            this.RegFormBoxPassword.Size = new Size(this.RegFormBoxPassword.Size.Width, 30);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        Point lastPoint;

        private void RegFormButtonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void RegFormButtonBack_Click(object sender, EventArgs e)
        {
            LoginForm lg = new LoginForm();
            lg.Show();
            this.Hide();
        }
        private SqlConnection SqlConnection = null;

        private void RegForm_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["KeyB"].ConnectionString);
            SqlConnection.Open();
            if (SqlConnection.State == ConnectionState.Open)
            {
                MessageBox.Show("Conekt est");
            }
            else
            {
                MessageBox.Show("netu");
            }
        }




        private void RegFormButtonConfirm_Click(object sender, EventArgs e)
        {


            //SqlCommand comand = new SqlCommand($"INSERT into Klients(K_Pasts,K_Parole,K_Vards,K_Uzvards,K_Birthday) VALUES(@K_Pasts,@K_Parole,@K_Vards,@K_Uzvards,@K_Birthday)", SqlConnection);
            //DateTime date = DateTime.Parse(RegFormBoxBirthday.Text);
            //comand.Parameters.AddWithValue("K_Pasts", RegFormBoxLogin.Text);
            //comand.Parameters.AddWithValue("K_Parole", RegFormBoxPassword.Text);
            //comand.Parameters.AddWithValue("K_Vards", RegFormBoxVards.Text);
            //comand.Parameters.AddWithValue("K_Uzvards", RegFormBoxUzvards.Text);
            //comand.Parameters.AddWithValue("K_Birthday", $"{date.Month}/{date.Day}/{date.Year}");

            try
            {

                SqlCommand comand = new SqlCommand($"INSERT into Klients(K_Pasts,K_Parole,K_Vards,K_Uzvards,K_Birthday) VALUES(@K_Pasts,@K_Parole,@K_Vards,@K_Uzvards,@K_Birthday)", SqlConnection);
                DateTime date = DateTime.Parse(RegFormBoxBirthday.Text);
                comand.Parameters.AddWithValue("K_Pasts", RegFormBoxLogin.Text);
                comand.Parameters.AddWithValue("K_Parole", RegFormBoxPassword.Text);
                comand.Parameters.AddWithValue("K_Vards", RegFormBoxVards.Text);
                comand.Parameters.AddWithValue("K_Uzvards", RegFormBoxUzvards.Text);
                comand.Parameters.AddWithValue("K_Birthday", $"{date.Month}/{date.Day}/{date.Year}");
                MessageBox.Show(comand.ExecuteNonQuery().ToString());
                MessageBox.Show("Jusu akaunts ir pieregistrec ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoginForm lg = new LoginForm();
                RegForm regForm = new RegForm();
                regForm.Hide();
                lg.Show();
                this.Hide();

            }
            catch
            {
                MessageBox.Show(" Format is not corect ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RegFormBoxLogin.Clear();
                RegFormBoxPassword.Clear();
                RegFormBoxVards.Clear();
                RegFormBoxUzvards.Clear();
                RegFormBoxBirthday.Clear();
                RegForm regForm = new RegForm();
                this.Hide();
                regForm.Show();

            }
          
        
        //MessageBox.Show(comand.ExecuteNonQuery().ToString());
        //    MessageBox.Show("Jusu akaunts ir pieregistrec ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    LoginForm lg = new LoginForm();
        //    lg.Show();
        //    this.Hide();

        }
    }
}
