﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoNoma
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }  
        private SqlConnection SqlConnection = null;
        private void AdminForm_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["KeyB"].ConnectionString);//PODKLUCENIJE K DB
            SqlConnection.Open();
            if (SqlConnection.State == ConnectionState.Open)
            {
                MessageBox.Show("Conekt est");
            }
        }



        private void buttonINSERT_Click_1(object sender, EventArgs e)
        {
            try
            {
                DateTime date = DateTime.Parse(InsertK_BirthdayBox.Text);
                string query = $"INSERT into Klients(K_Pasts,K_Vards,K_Uzvards,K_Parole,K_Birthday)VALUES(@K_Pasts,@K_Vards,@K_Uzvards,@K_Parole,@K_Birthday)";


                SqlCommand command = new SqlCommand(query, SqlConnection);

                command.Parameters.AddWithValue("K_Pasts", InsertK_PastsBox.Text);
                command.Parameters.AddWithValue("K_Parole", InsertK_ParoleBoxx.Text);
                command.Parameters.AddWithValue("K_Vards", InsertK_VardsBox.Text);
                command.Parameters.AddWithValue("K_Uzvards", InsertK_UzvardsBox.Text);
                command.Parameters.AddWithValue("K_Birthday", $"{date.Month}/{date.Day}/{date.Year}");
                MessageBox.Show(command.ExecuteNonQuery().ToString());
            }
            catch
            {
                MessageBox.Show(" Format is not corect ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                InsertK_PastsBox.Clear();
                InsertK_ParoleBoxx.Clear();
                InsertK_VardsBox.Clear();
                InsertK_UzvardsBox.Clear();
               
                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();
            }
        }

        private void tabPage2_Enter(object sender, EventArgs e)
        {
            SqlDataAdapter dataAdapter = new SqlDataAdapter
                ("select * from Klients", SqlConnection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            dataGridView1.DataSource = dataSet.Tables[0];
        }

     

        private void buttonDrop_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"delete from Klients where K_ID = @K_ID";
                SqlCommand command = new SqlCommand(query, SqlConnection);
                command.Parameters.AddWithValue("K_ID", DropBox_Auto.Text);
                MessageBox.Show(command.ExecuteNonQuery().ToString());
            }
            catch 
            {
                MessageBox.Show(" ERROR ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DropBox_Auto.Clear();
              

                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();

            }
   
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tabPage3_Enter(object sender, EventArgs e)
        {
            SqlDataAdapter dataAdapter = new SqlDataAdapter
               ("select * from Klients", SqlConnection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            dataGridView2.DataSource = dataSet.Tables[0];
        }
        private void tabControl1_Enter(object sender, EventArgs e)
        {
            SqlDataAdapter dataAdapter = new SqlDataAdapter
           ("select * from Klients", SqlConnection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            dataGridView2.DataSource = dataSet.Tables[0];
        }
       


        private void InsertAuto_Click(object sender, EventArgs e)
        {
            try
            {

                string query = $"INSERT into Automobili(A_Zimols,A_Modelis,A_CenaPar1H)VALUES(@A_Zimols,@A_Modelis,@A_CenaPar1H)";


                SqlCommand command = new SqlCommand(query, SqlConnection);

                command.Parameters.AddWithValue("A_Zimols", textBox5.Text);
                command.Parameters.AddWithValue("A_Modelis", textBox4.Text);
                command.Parameters.AddWithValue("A_CenaPar1H", textBox3.Text);

                MessageBox.Show(command.ExecuteNonQuery().ToString());
                textBox5.Clear();
                textBox4.Clear();
                textBox3.Clear();
                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();
            }
            catch
            {
                MessageBox.Show(" Format is not corect ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox5.Clear();
                textBox4.Clear();
                textBox3.Clear();


                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();
            }
        }

        private void UPDATEKlients_Click_1(object sender, EventArgs e)
        {
            try
            {
                var Lauks = LauksBox.Text;
                var Vertiba = VertibaBox.Text;
                var ID = IDBox;
                string query = $"update Klients set @Lauks=@Vertiba where K_ID = @ID ";
          
                SqlCommand command = new SqlCommand(query, SqlConnection);
                command.Parameters.AddWithValue("Lauks", LauksBox.Text);
                command.Parameters.AddWithValue("Vertiba", VertibaBox.Text);
                command.Parameters.AddWithValue("ID", IDBox.Text);
                MessageBox.Show(command.ExecuteNonQuery().ToString());
                LauksBox.Clear();
                VertibaBox.Clear();
                IDBox.Clear();
                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();

            }
            catch
            {
                MessageBox.Show(" ERROR ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LauksBox.Clear();
                VertibaBox.Clear();
                IDBox.Clear();


                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();


            }
        }

        private void tabPage5_Enter(object sender, EventArgs e)
        {
            SqlDataAdapter dataAdapter = new SqlDataAdapter
             ("select * from Automobili", SqlConnection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            dataGridView3.DataSource = dataSet.Tables[0];
        }

        private void DEL_Button_Auto_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"delete from Automobili where A_Numurs = @A_Numurs";
                SqlCommand command = new SqlCommand(query, SqlConnection);
                command.Parameters.AddWithValue("A_Numurs", DROP_Box_Auto.Text);
                MessageBox.Show(command.ExecuteNonQuery().ToString());
                DROP_Box_Auto.Clear();
            }
            catch
            {
                MessageBox.Show(" ERROR ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DropBox_Auto.Clear();


                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();

            }
        }

        private void tabPage6_Enter(object sender, EventArgs e)
        {
            SqlDataAdapter dataAdapter = new SqlDataAdapter
            ("select * from Automobili", SqlConnection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            dataGridView3.DataSource = dataSet.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var Lauks = LauksBox.Text;
                var Vertiba = VertibaBox.Text;
                var Numurs = IDBox;
                string query = $"update Klients set @Lauks=@Vertiba where K_ID = @ID ";//hujna s 244 strokoi i v predidushem update toze nado posmotret

                SqlCommand command = new SqlCommand(query, SqlConnection);
                command.Parameters.AddWithValue("Lauks", LauksBox.Text);
                command.Parameters.AddWithValue("Vertiba", VertibaBox.Text);
                command.Parameters.AddWithValue("ID", IDBox.Text);
                MessageBox.Show(command.ExecuteNonQuery().ToString());
                LauksBox.Clear();
                VertibaBox.Clear();
                IDBox.Clear();
                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();

            }
            catch
            {
                MessageBox.Show(" ERROR ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LauksBox.Clear();
                VertibaBox.Clear();
                IDBox.Clear();


                AdminForm adminForm = new AdminForm();
                this.Hide();
                adminForm.Show();


            }
        }
    }
    
}
