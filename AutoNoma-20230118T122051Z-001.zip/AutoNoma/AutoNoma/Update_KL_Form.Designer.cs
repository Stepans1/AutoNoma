﻿
namespace AutoNoma
{
    partial class Update_KL_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.textBox_Pasts = new System.Windows.Forms.TextBox();
            this.textBox_Vards = new System.Windows.Forms.TextBox();
            this.textBox_Uzvards = new System.Windows.Forms.TextBox();
            this.textBox_Parole = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.UPDATE_Button_KL = new System.Windows.Forms.Button();
            this.BACK_Button_Update_KL = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 78);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::AutoNoma.Properties.Resources._172618_update_icon;
            this.pictureBox2.Location = new System.Drawing.Point(690, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AutoNoma.Properties.Resources._9044458_erase_icon;
            this.pictureBox1.Location = new System.Drawing.Point(617, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(55, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(776, 150);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // textBox_ID
            // 
            this.textBox_ID.Location = new System.Drawing.Point(103, 240);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(128, 20);
            this.textBox_ID.TabIndex = 2;
            // 
            // textBox_Pasts
            // 
            this.textBox_Pasts.Location = new System.Drawing.Point(103, 266);
            this.textBox_Pasts.Name = "textBox_Pasts";
            this.textBox_Pasts.Size = new System.Drawing.Size(128, 20);
            this.textBox_Pasts.TabIndex = 3;
            // 
            // textBox_Vards
            // 
            this.textBox_Vards.Location = new System.Drawing.Point(103, 292);
            this.textBox_Vards.Name = "textBox_Vards";
            this.textBox_Vards.Size = new System.Drawing.Size(128, 20);
            this.textBox_Vards.TabIndex = 4;
            // 
            // textBox_Uzvards
            // 
            this.textBox_Uzvards.Location = new System.Drawing.Point(103, 318);
            this.textBox_Uzvards.Name = "textBox_Uzvards";
            this.textBox_Uzvards.Size = new System.Drawing.Size(128, 20);
            this.textBox_Uzvards.TabIndex = 5;
            // 
            // textBox_Parole
            // 
            this.textBox_Parole.Location = new System.Drawing.Point(103, 344);
            this.textBox_Parole.Name = "textBox_Parole";
            this.textBox_Parole.Size = new System.Drawing.Size(128, 20);
            this.textBox_Parole.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(57, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(31, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Pasts";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(31, 292);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Vards";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(13, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "Uzvards";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(31, 344);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "Parole";
            // 
            // UPDATE_Button_KL
            // 
            this.UPDATE_Button_KL.Location = new System.Drawing.Point(653, 259);
            this.UPDATE_Button_KL.Name = "UPDATE_Button_KL";
            this.UPDATE_Button_KL.Size = new System.Drawing.Size(92, 36);
            this.UPDATE_Button_KL.TabIndex = 14;
            this.UPDATE_Button_KL.Text = "UPDATE";
            this.UPDATE_Button_KL.UseVisualStyleBackColor = true;
            this.UPDATE_Button_KL.Click += new System.EventHandler(this.UPDATE_Button_KL_Click);
            // 
            // BACK_Button_Update_KL
            // 
            this.BACK_Button_Update_KL.Location = new System.Drawing.Point(653, 318);
            this.BACK_Button_Update_KL.Name = "BACK_Button_Update_KL";
            this.BACK_Button_Update_KL.Size = new System.Drawing.Size(92, 35);
            this.BACK_Button_Update_KL.TabIndex = 15;
            this.BACK_Button_Update_KL.Text = "BACK";
            this.BACK_Button_Update_KL.UseVisualStyleBackColor = true;
            this.BACK_Button_Update_KL.Click += new System.EventHandler(this.BACK_Button_Update_KL_Click);
            // 
            // Update_KL_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BACK_Button_Update_KL);
            this.Controls.Add(this.UPDATE_Button_KL);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_Parole);
            this.Controls.Add(this.textBox_Uzvards);
            this.Controls.Add(this.textBox_Vards);
            this.Controls.Add(this.textBox_Pasts);
            this.Controls.Add(this.textBox_ID);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Update_KL_Form";
            this.Text = "Update_KL_Form";
            this.Load += new System.EventHandler(this.Update_KL_Form_Load);
            this.Enter += new System.EventHandler(this.Update_KL_Form_Enter);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox_ID;
        private System.Windows.Forms.TextBox textBox_Pasts;
        private System.Windows.Forms.TextBox textBox_Vards;
        private System.Windows.Forms.TextBox textBox_Uzvards;
        private System.Windows.Forms.TextBox textBox_Parole;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button UPDATE_Button_KL;
        private System.Windows.Forms.Button BACK_Button_Update_KL;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}