﻿
namespace AutoNoma
{
    partial class RegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.RegFormBoxBirthday = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.RegFormBoxUzvards = new System.Windows.Forms.TextBox();
            this.RegFormBoxVards = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.RegFormButtonBack = new System.Windows.Forms.Button();
            this.RegFormButtonConfirm = new System.Windows.Forms.Button();
            this.RegFormBoxPassword = new System.Windows.Forms.TextBox();
            this.RegFormBoxLogin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RegFormButtonExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.panel1.Controls.Add(this.RegFormBoxBirthday);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.RegFormBoxUzvards);
            this.panel1.Controls.Add(this.RegFormBoxVards);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.RegFormButtonBack);
            this.panel1.Controls.Add(this.RegFormButtonConfirm);
            this.panel1.Controls.Add(this.RegFormBoxPassword);
            this.panel1.Controls.Add(this.RegFormBoxLogin);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(580, 450);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // RegFormBoxBirthday
            // 
            this.RegFormBoxBirthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormBoxBirthday.Location = new System.Drawing.Point(347, 286);
            this.RegFormBoxBirthday.Name = "RegFormBoxBirthday";
            this.RegFormBoxBirthday.Size = new System.Drawing.Size(220, 35);
            this.RegFormBoxBirthday.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bauhaus 93", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(52, 291);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(302, 30);
            this.label6.TabIndex = 11;
            this.label6.Text = "Birthday(MM/DD/YYYY):";
            // 
            // RegFormBoxUzvards
            // 
            this.RegFormBoxUzvards.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormBoxUzvards.Location = new System.Drawing.Point(183, 234);
            this.RegFormBoxUzvards.Name = "RegFormBoxUzvards";
            this.RegFormBoxUzvards.Size = new System.Drawing.Size(220, 35);
            this.RegFormBoxUzvards.TabIndex = 10;
            // 
            // RegFormBoxVards
            // 
            this.RegFormBoxVards.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormBoxVards.Location = new System.Drawing.Point(156, 183);
            this.RegFormBoxVards.Name = "RegFormBoxVards";
            this.RegFormBoxVards.Size = new System.Drawing.Size(220, 35);
            this.RegFormBoxVards.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bauhaus 93", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(50, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 30);
            this.label5.TabIndex = 8;
            this.label5.Text = "Surname:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bauhaus 93", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 30);
            this.label2.TabIndex = 7;
            this.label2.Text = "Name:";
            // 
            // RegFormButtonBack
            // 
            this.RegFormButtonBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RegFormButtonBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.RegFormButtonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RegFormButtonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormButtonBack.Location = new System.Drawing.Point(454, 98);
            this.RegFormButtonBack.Name = "RegFormButtonBack";
            this.RegFormButtonBack.Size = new System.Drawing.Size(96, 36);
            this.RegFormButtonBack.TabIndex = 6;
            this.RegFormButtonBack.Text = "BACK";
            this.RegFormButtonBack.UseVisualStyleBackColor = true;
            this.RegFormButtonBack.Click += new System.EventHandler(this.RegFormButtonBack_Click);
            // 
            // RegFormButtonConfirm
            // 
            this.RegFormButtonConfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.RegFormButtonConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RegFormButtonConfirm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.RegFormButtonConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RegFormButtonConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormButtonConfirm.Location = new System.Drawing.Point(212, 387);
            this.RegFormButtonConfirm.Name = "RegFormButtonConfirm";
            this.RegFormButtonConfirm.Size = new System.Drawing.Size(141, 36);
            this.RegFormButtonConfirm.TabIndex = 5;
            this.RegFormButtonConfirm.Text = "Confirm";
            this.RegFormButtonConfirm.UseVisualStyleBackColor = false;
            this.RegFormButtonConfirm.Click += new System.EventHandler(this.RegFormButtonConfirm_Click);
            // 
            // RegFormBoxPassword
            // 
            this.RegFormBoxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormBoxPassword.Location = new System.Drawing.Point(183, 142);
            this.RegFormBoxPassword.Name = "RegFormBoxPassword";
            this.RegFormBoxPassword.PasswordChar = '*';
            this.RegFormBoxPassword.Size = new System.Drawing.Size(220, 35);
            this.RegFormBoxPassword.TabIndex = 4;
            this.RegFormBoxPassword.UseSystemPasswordChar = true;
            // 
            // RegFormBoxLogin
            // 
            this.RegFormBoxLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormBoxLogin.Location = new System.Drawing.Point(144, 101);
            this.RegFormBoxLogin.Name = "RegFormBoxLogin";
            this.RegFormBoxLogin.Size = new System.Drawing.Size(269, 35);
            this.RegFormBoxLogin.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bauhaus 93", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 30);
            this.label4.TabIndex = 2;
            this.label4.Text = "Password:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bauhaus 93", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 30);
            this.label3.TabIndex = 1;
            this.label3.Text = "Email:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(51)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.RegFormButtonExit);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(637, 92);
            this.panel2.TabIndex = 0;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseMove);
            // 
            // RegFormButtonExit
            // 
            this.RegFormButtonExit.FlatAppearance.BorderSize = 0;
            this.RegFormButtonExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.RegFormButtonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RegFormButtonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegFormButtonExit.Location = new System.Drawing.Point(505, 12);
            this.RegFormButtonExit.Name = "RegFormButtonExit";
            this.RegFormButtonExit.Size = new System.Drawing.Size(75, 36);
            this.RegFormButtonExit.TabIndex = 1;
            this.RegFormButtonExit.Text = "X";
            this.RegFormButtonExit.UseVisualStyleBackColor = true;
            this.RegFormButtonExit.Click += new System.EventHandler(this.RegFormButtonExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bauhaus 93", 27.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(186, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registracija";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // RegForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ClientSize = new System.Drawing.Size(579, 450);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegForm";
            this.Text = "RegForm";
            this.Load += new System.EventHandler(this.RegForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox RegFormBoxPassword;
        private System.Windows.Forms.TextBox RegFormBoxLogin;
        private System.Windows.Forms.Button RegFormButtonConfirm;
        private System.Windows.Forms.Button RegFormButtonBack;
        private System.Windows.Forms.Button RegFormButtonExit;
        private System.Windows.Forms.TextBox RegFormBoxUzvards;
        private System.Windows.Forms.TextBox RegFormBoxVards;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox RegFormBoxBirthday;
        private System.Windows.Forms.Label label6;
    }
}