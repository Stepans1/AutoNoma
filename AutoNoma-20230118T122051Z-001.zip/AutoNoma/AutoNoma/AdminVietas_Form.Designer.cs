﻿
namespace AutoNoma
{
    partial class AdminVietas_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Darbibas_lable = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Update_Button = new System.Windows.Forms.Button();
            this.Delete_buton = new System.Windows.Forms.Button();
            this.Insert_Button = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_A_Zimols = new System.Windows.Forms.TextBox();
            this.textBox_AV_Vieta = new System.Windows.Forms.TextBox();
            this.textBox_A_Numurs = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.Delete_Img = new System.Windows.Forms.PictureBox();
            this.refresh_Img = new System.Windows.Forms.PictureBox();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Delete_Img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.refresh_Img)).BeginInit();
            this.SuspendLayout();
            // 
            // Darbibas_lable
            // 
            this.Darbibas_lable.AutoSize = true;
            this.Darbibas_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Darbibas_lable.Location = new System.Drawing.Point(944, 391);
            this.Darbibas_lable.Name = "Darbibas_lable";
            this.Darbibas_lable.Size = new System.Drawing.Size(161, 20);
            this.Darbibas_lable.TabIndex = 18;
            this.Darbibas_lable.Text = "Darbibas ar datiem";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.Update_Button);
            this.panel3.Controls.Add(this.Delete_buton);
            this.panel3.Controls.Add(this.Insert_Button);
            this.panel3.Location = new System.Drawing.Point(883, 433);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(269, 202);
            this.panel3.TabIndex = 17;
            // 
            // Update_Button
            // 
            this.Update_Button.Location = new System.Drawing.Point(98, 141);
            this.Update_Button.Name = "Update_Button";
            this.Update_Button.Size = new System.Drawing.Size(91, 36);
            this.Update_Button.TabIndex = 2;
            this.Update_Button.Text = "Update";
            this.Update_Button.UseVisualStyleBackColor = true;
            this.Update_Button.Click += new System.EventHandler(this.Update_Button_Click);
            // 
            // Delete_buton
            // 
            this.Delete_buton.Location = new System.Drawing.Point(98, 83);
            this.Delete_buton.Name = "Delete_buton";
            this.Delete_buton.Size = new System.Drawing.Size(91, 36);
            this.Delete_buton.TabIndex = 1;
            this.Delete_buton.Text = "Delete";
            this.Delete_buton.UseVisualStyleBackColor = true;
            this.Delete_buton.Click += new System.EventHandler(this.Delete_buton_Click);
            // 
            // Insert_Button
            // 
            this.Insert_Button.Location = new System.Drawing.Point(98, 22);
            this.Insert_Button.Name = "Insert_Button";
            this.Insert_Button.Size = new System.Drawing.Size(91, 36);
            this.Insert_Button.TabIndex = 0;
            this.Insert_Button.Text = "Insert";
            this.Insert_Button.UseVisualStyleBackColor = true;
            this.Insert_Button.Click += new System.EventHandler(this.Insert_Button_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox_A_Zimols);
            this.panel2.Controls.Add(this.textBox_AV_Vieta);
            this.panel2.Controls.Add(this.textBox_A_Numurs);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Location = new System.Drawing.Point(33, 378);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(513, 257);
            this.panel2.TabIndex = 16;
            // 
            // textBox_A_Zimols
            // 
            this.textBox_A_Zimols.Location = new System.Drawing.Point(270, 82);
            this.textBox_A_Zimols.Name = "textBox_A_Zimols";
            this.textBox_A_Zimols.Size = new System.Drawing.Size(115, 20);
            this.textBox_A_Zimols.TabIndex = 10;
            // 
            // textBox_AV_Vieta
            // 
            this.textBox_AV_Vieta.Location = new System.Drawing.Point(270, 56);
            this.textBox_AV_Vieta.Name = "textBox_AV_Vieta";
            this.textBox_AV_Vieta.Size = new System.Drawing.Size(115, 20);
            this.textBox_AV_Vieta.TabIndex = 8;
            // 
            // textBox_A_Numurs
            // 
            this.textBox_A_Numurs.Location = new System.Drawing.Point(270, 25);
            this.textBox_A_Numurs.Name = "textBox_A_Numurs";
            this.textBox_A_Numurs.Size = new System.Drawing.Size(115, 20);
            this.textBox_A_Numurs.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(186, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "A_Zimols";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(186, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "AV_Vieta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(171, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "A_Numurs";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(79, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pieraksti";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::AutoNoma.Properties.Resources._1086667_deals_examine_form_list_records_icon;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(61, 42);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 78);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1140, 294);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.Delete_Img);
            this.panel1.Controls.Add(this.refresh_Img);
            this.panel1.Location = new System.Drawing.Point(2, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1158, 55);
            this.panel1.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(292, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(167, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Atrasanas vieta ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(26, 14);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 25);
            this.label21.TabIndex = 7;
            this.label21.Text = "Klients";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(141, 14);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(122, 25);
            this.label22.TabIndex = 6;
            this.label22.Text = "Automobili";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // Delete_Img
            // 
            this.Delete_Img.Image = global::AutoNoma.Properties.Resources._9044458_erase_icon;
            this.Delete_Img.Location = new System.Drawing.Point(1064, 6);
            this.Delete_Img.Name = "Delete_Img";
            this.Delete_Img.Size = new System.Drawing.Size(39, 33);
            this.Delete_Img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Delete_Img.TabIndex = 4;
            this.Delete_Img.TabStop = false;
            this.Delete_Img.Click += new System.EventHandler(this.Delete_Img_Click);
            // 
            // refresh_Img
            // 
            this.refresh_Img.Image = global::AutoNoma.Properties.Resources._172618_update_icon;
            this.refresh_Img.Location = new System.Drawing.Point(1111, 6);
            this.refresh_Img.Name = "refresh_Img";
            this.refresh_Img.Size = new System.Drawing.Size(39, 33);
            this.refresh_Img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.refresh_Img.TabIndex = 3;
            this.refresh_Img.TabStop = false;
            this.refresh_Img.Click += new System.EventHandler(this.refresh_Img_Click);
            // 
            // AdminVietas_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 652);
            this.Controls.Add(this.Darbibas_lable);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminVietas_Form";
            this.Text = "AdminVietas_Form";
            this.Load += new System.EventHandler(this.AdminVietas_Form_Load);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Delete_Img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.refresh_Img)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Darbibas_lable;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Update_Button;
        private System.Windows.Forms.Button Delete_buton;
        private System.Windows.Forms.Button Insert_Button;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_A_Zimols;
        private System.Windows.Forms.TextBox textBox_AV_Vieta;
        private System.Windows.Forms.TextBox textBox_A_Numurs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox Delete_Img;
        private System.Windows.Forms.PictureBox refresh_Img;
    }
}