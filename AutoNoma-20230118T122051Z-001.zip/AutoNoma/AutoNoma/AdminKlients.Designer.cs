﻿
namespace AutoNoma
{
    partial class AdminKlients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage_Klients = new System.Windows.Forms.TabPage();
            this.Darbibas_lable = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Update_Button = new System.Windows.Forms.Button();
            this.Delete_buton = new System.Windows.Forms.Button();
            this.Insert_Button_Klients = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_Birthday = new System.Windows.Forms.TextBox();
            this.textBox_Parole = new System.Windows.Forms.TextBox();
            this.textBox_Vards = new System.Windows.Forms.TextBox();
            this.textBox_Uzvards = new System.Windows.Forms.TextBox();
            this.textBox_Pasts = new System.Windows.Forms.TextBox();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.Delete_Img = new System.Windows.Forms.PictureBox();
            this.refresh_Img = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_Klients.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Delete_Img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.refresh_Img)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage_Klients
            // 
            this.tabPage_Klients.Controls.Add(this.Darbibas_lable);
            this.tabPage_Klients.Controls.Add(this.panel3);
            this.tabPage_Klients.Controls.Add(this.panel2);
            this.tabPage_Klients.Controls.Add(this.dataGridView1);
            this.tabPage_Klients.Controls.Add(this.panel1);
            this.tabPage_Klients.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Klients.Name = "tabPage_Klients";
            this.tabPage_Klients.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Klients.Size = new System.Drawing.Size(1154, 626);
            this.tabPage_Klients.TabIndex = 0;
            this.tabPage_Klients.Text = "Klients";
            this.tabPage_Klients.UseVisualStyleBackColor = true;
            this.tabPage_Klients.Enter += new System.EventHandler(this.tabPage_Klients_Enter);
            // 
            // Darbibas_lable
            // 
            this.Darbibas_lable.AutoSize = true;
            this.Darbibas_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Darbibas_lable.Location = new System.Drawing.Point(938, 374);
            this.Darbibas_lable.Name = "Darbibas_lable";
            this.Darbibas_lable.Size = new System.Drawing.Size(161, 20);
            this.Darbibas_lable.TabIndex = 13;
            this.Darbibas_lable.Text = "Darbibas ar datiem";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.Update_Button);
            this.panel3.Controls.Add(this.Delete_buton);
            this.panel3.Controls.Add(this.Insert_Button_Klients);
            this.panel3.Location = new System.Drawing.Point(877, 416);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(269, 202);
            this.panel3.TabIndex = 3;
            // 
            // Update_Button
            // 
            this.Update_Button.Location = new System.Drawing.Point(98, 141);
            this.Update_Button.Name = "Update_Button";
            this.Update_Button.Size = new System.Drawing.Size(91, 36);
            this.Update_Button.TabIndex = 2;
            this.Update_Button.Text = "Update";
            this.Update_Button.UseVisualStyleBackColor = true;
            this.Update_Button.Click += new System.EventHandler(this.Update_Button_Click);
            // 
            // Delete_buton
            // 
            this.Delete_buton.Location = new System.Drawing.Point(98, 83);
            this.Delete_buton.Name = "Delete_buton";
            this.Delete_buton.Size = new System.Drawing.Size(91, 36);
            this.Delete_buton.TabIndex = 1;
            this.Delete_buton.Text = "Delete";
            this.Delete_buton.UseVisualStyleBackColor = true;
            this.Delete_buton.Click += new System.EventHandler(this.Delete_buton_Click);
            // 
            // Insert_Button_Klients
            // 
            this.Insert_Button_Klients.Location = new System.Drawing.Point(98, 22);
            this.Insert_Button_Klients.Name = "Insert_Button_Klients";
            this.Insert_Button_Klients.Size = new System.Drawing.Size(91, 36);
            this.Insert_Button_Klients.TabIndex = 0;
            this.Insert_Button_Klients.Text = "Insert";
            this.Insert_Button_Klients.UseVisualStyleBackColor = true;
            this.Insert_Button_Klients.Click += new System.EventHandler(this.Insert_Button_Klients_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox_Birthday);
            this.panel2.Controls.Add(this.textBox_Parole);
            this.panel2.Controls.Add(this.textBox_Vards);
            this.panel2.Controls.Add(this.textBox_Uzvards);
            this.panel2.Controls.Add(this.textBox_Pasts);
            this.panel2.Controls.Add(this.textBox_ID);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Location = new System.Drawing.Point(27, 361);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(513, 257);
            this.panel2.TabIndex = 2;
            // 
            // textBox_Birthday
            // 
            this.textBox_Birthday.Location = new System.Drawing.Point(270, 176);
            this.textBox_Birthday.Name = "textBox_Birthday";
            this.textBox_Birthday.Size = new System.Drawing.Size(115, 20);
            this.textBox_Birthday.TabIndex = 12;
            // 
            // textBox_Parole
            // 
            this.textBox_Parole.Location = new System.Drawing.Point(270, 147);
            this.textBox_Parole.Name = "textBox_Parole";
            this.textBox_Parole.Size = new System.Drawing.Size(115, 20);
            this.textBox_Parole.TabIndex = 11;
            // 
            // textBox_Vards
            // 
            this.textBox_Vards.Location = new System.Drawing.Point(270, 82);
            this.textBox_Vards.Name = "textBox_Vards";
            this.textBox_Vards.Size = new System.Drawing.Size(115, 20);
            this.textBox_Vards.TabIndex = 10;
            // 
            // textBox_Uzvards
            // 
            this.textBox_Uzvards.Location = new System.Drawing.Point(270, 114);
            this.textBox_Uzvards.Name = "textBox_Uzvards";
            this.textBox_Uzvards.Size = new System.Drawing.Size(115, 20);
            this.textBox_Uzvards.TabIndex = 9;
            // 
            // textBox_Pasts
            // 
            this.textBox_Pasts.Location = new System.Drawing.Point(270, 56);
            this.textBox_Pasts.Name = "textBox_Pasts";
            this.textBox_Pasts.Size = new System.Drawing.Size(115, 20);
            this.textBox_Pasts.TabIndex = 8;
            // 
            // textBox_ID
            // 
            this.textBox_ID.Location = new System.Drawing.Point(270, 25);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(115, 20);
            this.textBox_ID.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(171, 174);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "K_Birthday";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(186, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "K_Parole";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(169, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "K_Uzvards";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(186, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "K_Vards";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(186, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "K_Pasts";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(212, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "K_ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(79, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pieraksti";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::AutoNoma.Properties.Resources._1086667_deals_examine_form_list_records_icon;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(61, 42);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1140, 294);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.Delete_Img);
            this.panel1.Controls.Add(this.refresh_Img);
            this.panel1.Location = new System.Drawing.Point(-4, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1158, 55);
            this.panel1.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(292, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(183, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Atrasanas vieta ";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(26, 14);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 25);
            this.label21.TabIndex = 7;
            this.label21.Text = "Klients";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(141, 14);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(122, 25);
            this.label22.TabIndex = 6;
            this.label22.Text = "Automobili";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // Delete_Img
            // 
            this.Delete_Img.Image = global::AutoNoma.Properties.Resources._9044458_erase_icon;
            this.Delete_Img.Location = new System.Drawing.Point(1064, 6);
            this.Delete_Img.Name = "Delete_Img";
            this.Delete_Img.Size = new System.Drawing.Size(39, 33);
            this.Delete_Img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Delete_Img.TabIndex = 4;
            this.Delete_Img.TabStop = false;
            this.Delete_Img.Click += new System.EventHandler(this.Delete_Img_Click);
            // 
            // refresh_Img
            // 
            this.refresh_Img.Image = global::AutoNoma.Properties.Resources._172618_update_icon;
            this.refresh_Img.Location = new System.Drawing.Point(1111, 6);
            this.refresh_Img.Name = "refresh_Img";
            this.refresh_Img.Size = new System.Drawing.Size(39, 33);
            this.refresh_Img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.refresh_Img.TabIndex = 3;
            this.refresh_Img.TabStop = false;
            this.refresh_Img.Click += new System.EventHandler(this.refresh_Img_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_Klients);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1162, 652);
            this.tabControl1.TabIndex = 0;
            // 
            // AdminKlients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 652);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminKlients";
            this.Text = "AdminFormV3";
            this.Load += new System.EventHandler(this.AdminFormV3_Load);
            this.tabPage_Klients.ResumeLayout(false);
            this.tabPage_Klients.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Delete_Img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.refresh_Img)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage_Klients;
        private System.Windows.Forms.Label Darbibas_lable;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Update_Button;
        private System.Windows.Forms.Button Delete_buton;
        private System.Windows.Forms.Button Insert_Button_Klients;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_Birthday;
        private System.Windows.Forms.TextBox textBox_Parole;
        private System.Windows.Forms.TextBox textBox_Vards;
        private System.Windows.Forms.TextBox textBox_Uzvards;
        private System.Windows.Forms.TextBox textBox_Pasts;
        private System.Windows.Forms.TextBox textBox_ID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox Delete_Img;
        private System.Windows.Forms.PictureBox refresh_Img;
        private System.Windows.Forms.TabControl tabControl1;
    }
}