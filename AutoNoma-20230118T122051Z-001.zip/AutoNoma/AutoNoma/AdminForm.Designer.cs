﻿
namespace AutoNoma
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.DEL_Button_Auto = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.DROP_Box_Auto = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.InsertAuto = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.UPDATEKlients = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.IDBox = new System.Windows.Forms.TextBox();
            this.VertibaBox = new System.Windows.Forms.TextBox();
            this.LauksBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.InsertK_BirthdayBox = new System.Windows.Forms.TextBox();
            this.InsertK_ParoleBoxx = new System.Windows.Forms.TextBox();
            this.InsertK_UzvardsBox = new System.Windows.Forms.TextBox();
            this.InsertK_VardsBox = new System.Windows.Forms.TextBox();
            this.InsertK_PastsBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonINSERT = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.DropBox_Auto = new System.Windows.Forms.TextBox();
            this.buttonDrop = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.Lauks_Box_Auto = new System.Windows.Forms.TextBox();
            this.Vertiba_Box_Auto = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Numurs_Box_Auto = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.DEL_Button_Auto);
            this.tabPage5.Controls.Add(this.label10);
            this.tabPage5.Controls.Add(this.DROP_Box_Auto);
            this.tabPage5.Controls.Add(this.dataGridView3);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1104, 448);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "DROP Automobilii";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Enter += new System.EventHandler(this.tabPage5_Enter);
            // 
            // DEL_Button_Auto
            // 
            this.DEL_Button_Auto.Location = new System.Drawing.Point(0, 251);
            this.DEL_Button_Auto.Name = "DEL_Button_Auto";
            this.DEL_Button_Auto.Size = new System.Drawing.Size(100, 32);
            this.DEL_Button_Auto.TabIndex = 3;
            this.DEL_Button_Auto.Text = "DEL";
            this.DEL_Button_Auto.UseVisualStyleBackColor = true;
            this.DEL_Button_Auto.Click += new System.EventHandler(this.DEL_Button_Auto_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(-5, 179);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 25);
            this.label10.TabIndex = 2;
            this.label10.Text = "A_Numurs";
            // 
            // DROP_Box_Auto
            // 
            this.DROP_Box_Auto.Location = new System.Drawing.Point(0, 207);
            this.DROP_Box_Auto.Name = "DROP_Box_Auto";
            this.DROP_Box_Auto.Size = new System.Drawing.Size(100, 20);
            this.DROP_Box_Auto.TabIndex = 1;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(-4, 0);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1108, 152);
            this.dataGridView3.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.InsertAuto);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.textBox3);
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.textBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1104, 448);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "INSERT Automobili";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // InsertAuto
            // 
            this.InsertAuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InsertAuto.Location = new System.Drawing.Point(29, 211);
            this.InsertAuto.Name = "InsertAuto";
            this.InsertAuto.Size = new System.Drawing.Size(111, 42);
            this.InsertAuto.TabIndex = 17;
            this.InsertAuto.Text = "INSERT";
            this.InsertAuto.UseVisualStyleBackColor = true;
            this.InsertAuto.Click += new System.EventHandler(this.InsertAuto_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(24, 139);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(176, 29);
            this.label12.TabIndex = 16;
            this.label12.Text = "A_CenaPar1H";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(24, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 29);
            this.label13.TabIndex = 15;
            this.label13.Text = "A_Modelis";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(24, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 29);
            this.label14.TabIndex = 14;
            this.label14.Text = "A_Zimols";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(29, 171);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(303, 20);
            this.textBox3.TabIndex = 13;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(29, 110);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(303, 20);
            this.textBox4.TabIndex = 12;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(29, 52);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(303, 20);
            this.textBox5.TabIndex = 11;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.UPDATEKlients);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.IDBox);
            this.tabPage3.Controls.Add(this.VertibaBox);
            this.tabPage3.Controls.Add(this.LauksBox);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1104, 448);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "UPDATE Klients";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Enter += new System.EventHandler(this.tabPage2_Enter);
            // 
            // UPDATEKlients
            // 
            this.UPDATEKlients.Location = new System.Drawing.Point(13, 408);
            this.UPDATEKlients.Name = "UPDATEKlients";
            this.UPDATEKlients.Size = new System.Drawing.Size(75, 23);
            this.UPDATEKlients.TabIndex = 7;
            this.UPDATEKlients.Text = "UPDATE";
            this.UPDATEKlients.UseVisualStyleBackColor = true;
            this.UPDATEKlients.Click += new System.EventHandler(this.UPDATEKlients_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(8, 332);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 25);
            this.label9.TabIndex = 6;
            this.label9.Text = "ID";
            // 
            // IDBox
            // 
            this.IDBox.Location = new System.Drawing.Point(8, 360);
            this.IDBox.Name = "IDBox";
            this.IDBox.Size = new System.Drawing.Size(116, 20);
            this.IDBox.TabIndex = 5;
            // 
            // VertibaBox
            // 
            this.VertibaBox.Location = new System.Drawing.Point(8, 309);
            this.VertibaBox.Name = "VertibaBox";
            this.VertibaBox.Size = new System.Drawing.Size(116, 20);
            this.VertibaBox.TabIndex = 3;
            // 
            // LauksBox
            // 
            this.LauksBox.Location = new System.Drawing.Point(8, 246);
            this.LauksBox.Name = "LauksBox";
            this.LauksBox.Size = new System.Drawing.Size(116, 20);
            this.LauksBox.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(8, 281);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 25);
            this.label8.TabIndex = 4;
            this.label8.Text = "Jauna vertiba";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(8, 218);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Lauks";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1098, 197);
            this.dataGridView2.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.InsertK_BirthdayBox);
            this.tabPage1.Controls.Add(this.InsertK_ParoleBoxx);
            this.tabPage1.Controls.Add(this.InsertK_UzvardsBox);
            this.tabPage1.Controls.Add(this.InsertK_VardsBox);
            this.tabPage1.Controls.Add(this.InsertK_PastsBox);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.buttonINSERT);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1104, 448);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "INSERT Klients";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(1071, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "X";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // InsertK_BirthdayBox
            // 
            this.InsertK_BirthdayBox.Location = new System.Drawing.Point(408, 143);
            this.InsertK_BirthdayBox.Name = "InsertK_BirthdayBox";
            this.InsertK_BirthdayBox.Size = new System.Drawing.Size(303, 20);
            this.InsertK_BirthdayBox.TabIndex = 10;
            // 
            // InsertK_ParoleBoxx
            // 
            this.InsertK_ParoleBoxx.Location = new System.Drawing.Point(408, 85);
            this.InsertK_ParoleBoxx.Name = "InsertK_ParoleBoxx";
            this.InsertK_ParoleBoxx.Size = new System.Drawing.Size(303, 20);
            this.InsertK_ParoleBoxx.TabIndex = 8;
            // 
            // InsertK_UzvardsBox
            // 
            this.InsertK_UzvardsBox.Location = new System.Drawing.Point(22, 204);
            this.InsertK_UzvardsBox.Name = "InsertK_UzvardsBox";
            this.InsertK_UzvardsBox.Size = new System.Drawing.Size(303, 20);
            this.InsertK_UzvardsBox.TabIndex = 2;
            // 
            // InsertK_VardsBox
            // 
            this.InsertK_VardsBox.Location = new System.Drawing.Point(22, 143);
            this.InsertK_VardsBox.Name = "InsertK_VardsBox";
            this.InsertK_VardsBox.Size = new System.Drawing.Size(303, 20);
            this.InsertK_VardsBox.TabIndex = 1;
            // 
            // InsertK_PastsBox
            // 
            this.InsertK_PastsBox.Location = new System.Drawing.Point(22, 85);
            this.InsertK_PastsBox.Name = "InsertK_PastsBox";
            this.InsertK_PastsBox.Size = new System.Drawing.Size(303, 20);
            this.InsertK_PastsBox.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(403, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 29);
            this.label5.TabIndex = 9;
            this.label5.Text = "K_Birthday";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(403, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 29);
            this.label4.TabIndex = 7;
            this.label4.Text = "K_Parole";
            // 
            // buttonINSERT
            // 
            this.buttonINSERT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonINSERT.Location = new System.Drawing.Point(22, 244);
            this.buttonINSERT.Name = "buttonINSERT";
            this.buttonINSERT.Size = new System.Drawing.Size(111, 42);
            this.buttonINSERT.TabIndex = 6;
            this.buttonINSERT.Text = "INSERT";
            this.buttonINSERT.UseVisualStyleBackColor = true;
            this.buttonINSERT.Click += new System.EventHandler(this.buttonINSERT_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(17, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 29);
            this.label3.TabIndex = 5;
            this.label3.Text = "K_Uzvards";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(17, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "K_Vards";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(17, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "K_Pasts";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1112, 474);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Enter += new System.EventHandler(this.tabControl1_Enter);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1104, 448);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "DROP Klients";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Enter += new System.EventHandler(this.tabPage2_Enter);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1098, 442);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button1);
            this.tabPage6.Controls.Add(this.Numurs_Box_Auto);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.Vertiba_Box_Auto);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.Lauks_Box_Auto);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.dataGridView4);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1104, 448);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "UPDATE Automobili";
            this.tabPage6.UseVisualStyleBackColor = true;
            this.tabPage6.Enter += new System.EventHandler(this.tabPage6_Enter);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(0, 0);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1104, 163);
            this.dataGridView4.TabIndex = 0;
            // 
            // DropBox_Auto
            // 
            this.DropBox_Auto.Location = new System.Drawing.Point(3, 224);
            this.DropBox_Auto.Name = "DropBox_Auto";
            this.DropBox_Auto.Size = new System.Drawing.Size(68, 20);
            this.DropBox_Auto.TabIndex = 1;
            // 
            // buttonDrop
            // 
            this.buttonDrop.Location = new System.Drawing.Point(3, 334);
            this.buttonDrop.Name = "buttonDrop";
            this.buttonDrop.Size = new System.Drawing.Size(98, 32);
            this.buttonDrop.TabIndex = 2;
            this.buttonDrop.Text = "DEL";
            this.buttonDrop.UseVisualStyleBackColor = true;
            this.buttonDrop.Click += new System.EventHandler(this.buttonDrop_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1092, 215);
            this.dataGridView1.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(8, 185);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 25);
            this.label11.TabIndex = 1;
            this.label11.Text = "Lauks";
            // 
            // Lauks_Box_Auto
            // 
            this.Lauks_Box_Auto.Location = new System.Drawing.Point(8, 213);
            this.Lauks_Box_Auto.Name = "Lauks_Box_Auto";
            this.Lauks_Box_Auto.Size = new System.Drawing.Size(100, 20);
            this.Lauks_Box_Auto.TabIndex = 2;
            // 
            // Vertiba_Box_Auto
            // 
            this.Vertiba_Box_Auto.Location = new System.Drawing.Point(8, 279);
            this.Vertiba_Box_Auto.Name = "Vertiba_Box_Auto";
            this.Vertiba_Box_Auto.Size = new System.Drawing.Size(100, 20);
            this.Vertiba_Box_Auto.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(8, 251);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 25);
            this.label15.TabIndex = 3;
            this.label15.Text = "Vertiba";
            // 
            // Numurs_Box_Auto
            // 
            this.Numurs_Box_Auto.Location = new System.Drawing.Point(8, 348);
            this.Numurs_Box_Auto.Name = "Numurs_Box_Auto";
            this.Numurs_Box_Auto.Size = new System.Drawing.Size(100, 20);
            this.Numurs_Box_Auto.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(8, 320);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 25);
            this.label16.TabIndex = 5;
            this.label16.Text = "A_Numurs";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(8, 394);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 31);
            this.button1.TabIndex = 7;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1112, 474);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminForm";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox DROP_Box_Auto;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button InsertAuto;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button UPDATEKlients;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox IDBox;
        private System.Windows.Forms.TextBox VertibaBox;
        private System.Windows.Forms.TextBox LauksBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox InsertK_BirthdayBox;
        private System.Windows.Forms.TextBox InsertK_ParoleBoxx;
        private System.Windows.Forms.TextBox InsertK_UzvardsBox;
        private System.Windows.Forms.TextBox InsertK_VardsBox;
        private System.Windows.Forms.TextBox InsertK_PastsBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonINSERT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button DEL_Button_Auto;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox DropBox_Auto;
        private System.Windows.Forms.Button buttonDrop;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Numurs_Box_Auto;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Vertiba_Box_Auto;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Lauks_Box_Auto;
        private System.Windows.Forms.Label label11;
    }
}