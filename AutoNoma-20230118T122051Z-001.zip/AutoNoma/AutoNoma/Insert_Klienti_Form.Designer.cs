﻿
namespace AutoNoma
{
    partial class Insert_Klienti_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Lable_Pasts = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_K_Pasts = new System.Windows.Forms.TextBox();
            this.textBox_K_Vards = new System.Windows.Forms.TextBox();
            this.textBox_K_Uzvards = new System.Windows.Forms.TextBox();
            this.textBox_K_Parole = new System.Windows.Forms.TextBox();
            this.textBox_K_Birthday = new System.Windows.Forms.TextBox();
            this.Insert_Klienti_Button = new System.Windows.Forms.Button();
            this.BACK_Insert_Kl_Button = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 72);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AutoNoma.Properties.Resources._9044458_erase_icon;
            this.pictureBox1.Location = new System.Drawing.Point(687, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 39);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Insert Klients";
            // 
            // Lable_Pasts
            // 
            this.Lable_Pasts.AutoSize = true;
            this.Lable_Pasts.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lable_Pasts.Location = new System.Drawing.Point(174, 112);
            this.Lable_Pasts.Name = "Lable_Pasts";
            this.Lable_Pasts.Size = new System.Drawing.Size(83, 24);
            this.Lable_Pasts.TabIndex = 1;
            this.Lable_Pasts.Text = "K_Pasts";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(168, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "K_Vards";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(149, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "K_Uzvards";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(162, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "K_Parole";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(148, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "K_Birthday";
            // 
            // textBox_K_Pasts
            // 
            this.textBox_K_Pasts.Location = new System.Drawing.Point(283, 117);
            this.textBox_K_Pasts.Name = "textBox_K_Pasts";
            this.textBox_K_Pasts.Size = new System.Drawing.Size(151, 20);
            this.textBox_K_Pasts.TabIndex = 6;
            // 
            // textBox_K_Vards
            // 
            this.textBox_K_Vards.Location = new System.Drawing.Point(283, 163);
            this.textBox_K_Vards.Name = "textBox_K_Vards";
            this.textBox_K_Vards.Size = new System.Drawing.Size(151, 20);
            this.textBox_K_Vards.TabIndex = 7;
            // 
            // textBox_K_Uzvards
            // 
            this.textBox_K_Uzvards.Location = new System.Drawing.Point(283, 201);
            this.textBox_K_Uzvards.Name = "textBox_K_Uzvards";
            this.textBox_K_Uzvards.Size = new System.Drawing.Size(151, 20);
            this.textBox_K_Uzvards.TabIndex = 8;
            // 
            // textBox_K_Parole
            // 
            this.textBox_K_Parole.Location = new System.Drawing.Point(283, 239);
            this.textBox_K_Parole.Name = "textBox_K_Parole";
            this.textBox_K_Parole.Size = new System.Drawing.Size(151, 20);
            this.textBox_K_Parole.TabIndex = 9;
            // 
            // textBox_K_Birthday
            // 
            this.textBox_K_Birthday.Location = new System.Drawing.Point(283, 278);
            this.textBox_K_Birthday.Name = "textBox_K_Birthday";
            this.textBox_K_Birthday.Size = new System.Drawing.Size(151, 20);
            this.textBox_K_Birthday.TabIndex = 10;
            // 
            // Insert_Klienti_Button
            // 
            this.Insert_Klienti_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Insert_Klienti_Button.Location = new System.Drawing.Point(152, 342);
            this.Insert_Klienti_Button.Name = "Insert_Klienti_Button";
            this.Insert_Klienti_Button.Size = new System.Drawing.Size(282, 39);
            this.Insert_Klienti_Button.TabIndex = 11;
            this.Insert_Klienti_Button.Text = "Insert";
            this.Insert_Klienti_Button.UseVisualStyleBackColor = true;
            this.Insert_Klienti_Button.Click += new System.EventHandler(this.Insert_Klienti_Button_Click);
            // 
            // BACK_Insert_Kl_Button
            // 
            this.BACK_Insert_Kl_Button.Location = new System.Drawing.Point(713, 78);
            this.BACK_Insert_Kl_Button.Name = "BACK_Insert_Kl_Button";
            this.BACK_Insert_Kl_Button.Size = new System.Drawing.Size(75, 23);
            this.BACK_Insert_Kl_Button.TabIndex = 12;
            this.BACK_Insert_Kl_Button.Text = "BACK";
            this.BACK_Insert_Kl_Button.UseVisualStyleBackColor = true;
            this.BACK_Insert_Kl_Button.Click += new System.EventHandler(this.BACK_Insert_Kl_Button_Click);
            // 
            // Insert_Klienti_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BACK_Insert_Kl_Button);
            this.Controls.Add(this.Insert_Klienti_Button);
            this.Controls.Add(this.textBox_K_Birthday);
            this.Controls.Add(this.textBox_K_Parole);
            this.Controls.Add(this.textBox_K_Uzvards);
            this.Controls.Add(this.textBox_K_Vards);
            this.Controls.Add(this.textBox_K_Pasts);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Lable_Pasts);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Insert_Klienti_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Insert_Klienti_Form";
            this.Load += new System.EventHandler(this.Insert_Klienti_Form_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lable_Pasts;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_K_Pasts;
        private System.Windows.Forms.TextBox textBox_K_Vards;
        private System.Windows.Forms.TextBox textBox_K_Uzvards;
        private System.Windows.Forms.TextBox textBox_K_Parole;
        private System.Windows.Forms.TextBox textBox_K_Birthday;
        private System.Windows.Forms.Button Insert_Klienti_Button;
        private System.Windows.Forms.Button BACK_Insert_Kl_Button;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}