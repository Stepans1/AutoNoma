﻿
namespace AutoNoma
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label Login;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.CloseButon = new System.Windows.Forms.Label();
            this.Loginbox = new System.Windows.Forms.TextBox();
            this.paswordBox = new System.Windows.Forms.TextBox();
            this.panelLogin = new System.Windows.Forms.Panel();
            this.LoginFormButtonReg = new System.Windows.Forms.Button();
            this.EnterButon = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            Login = new System.Windows.Forms.Label();
            this.panelLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Login
            // 
            Login.AutoSize = true;
            Login.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Login.Location = new System.Drawing.Point(191, 32);
            Login.Name = "Login";
            Login.Size = new System.Drawing.Size(92, 34);
            Login.TabIndex = 0;
            Login.Text = "Login";
            // 
            // CloseButon
            // 
            this.CloseButon.AutoSize = true;
            this.CloseButon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButon.Location = new System.Drawing.Point(406, 9);
            this.CloseButon.Name = "CloseButon";
            this.CloseButon.Size = new System.Drawing.Size(14, 13);
            this.CloseButon.TabIndex = 1;
            this.CloseButon.Text = "X";
            this.CloseButon.Click += new System.EventHandler(this.CloseButon_Click);
            this.CloseButon.MouseEnter += new System.EventHandler(this.CloseButon_MouseEnter);
            this.CloseButon.MouseLeave += new System.EventHandler(this.CloseButon_MouseLeave);
            // 
            // Loginbox
            // 
            this.Loginbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Loginbox.Location = new System.Drawing.Point(155, 174);
            this.Loginbox.Multiline = true;
            this.Loginbox.Name = "Loginbox";
            this.Loginbox.Size = new System.Drawing.Size(215, 43);
            this.Loginbox.TabIndex = 5;
            // 
            // paswordBox
            // 
            this.paswordBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.paswordBox.Location = new System.Drawing.Point(155, 280);
            this.paswordBox.Name = "paswordBox";
            this.paswordBox.PasswordChar = '*';
            this.paswordBox.Size = new System.Drawing.Size(215, 35);
            this.paswordBox.TabIndex = 4;
            this.paswordBox.UseSystemPasswordChar = true;
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.Turquoise;
            this.panelLogin.Controls.Add(this.LoginFormButtonReg);
            this.panelLogin.Controls.Add(this.CloseButon);
            this.panelLogin.Controls.Add(Login);
            this.panelLogin.Location = new System.Drawing.Point(0, 0);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(423, 100);
            this.panelLogin.TabIndex = 1;
            this.panelLogin.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelLogin_MouseDown);
            this.panelLogin.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelLogin_MouseMove);
            // 
            // LoginFormButtonReg
            // 
            this.LoginFormButtonReg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoginFormButtonReg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LoginFormButtonReg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoginFormButtonReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LoginFormButtonReg.Location = new System.Drawing.Point(12, 12);
            this.LoginFormButtonReg.Name = "LoginFormButtonReg";
            this.LoginFormButtonReg.Size = new System.Drawing.Size(113, 38);
            this.LoginFormButtonReg.TabIndex = 2;
            this.LoginFormButtonReg.Text = "Sign up";
            this.LoginFormButtonReg.UseVisualStyleBackColor = true;
            this.LoginFormButtonReg.Click += new System.EventHandler(this.LoginFormButtonReg_Click);
            // 
            // EnterButon
            // 
            this.EnterButon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EnterButon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.EnterButon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EnterButon.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EnterButon.Location = new System.Drawing.Point(174, 376);
            this.EnterButon.Name = "EnterButon";
            this.EnterButon.Size = new System.Drawing.Size(91, 33);
            this.EnterButon.TabIndex = 6;
            this.EnterButon.Text = "Enter";
            this.EnterButon.UseVisualStyleBackColor = true;
            this.EnterButon.Click += new System.EventHandler(this.EnterButon_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AutoNoma.Properties.Resources._299105_lock_icon;
            this.pictureBox1.Location = new System.Drawing.Point(31, 280);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(77, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::AutoNoma.Properties.Resources.email;
            this.pictureBox2.Location = new System.Drawing.Point(31, 174);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(77, 43);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(423, 421);
            this.Controls.Add(this.EnterButon);
            this.Controls.Add(this.paswordBox);
            this.Controls.Add(this.Loginbox);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LoginForm";
            this.Text = "RegistracijaForm";
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LoginForm_MouseDown_1);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LoginForm_MouseMove_1);
            this.panelLogin.ResumeLayout(false);
            this.panelLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CloseButon;
        private System.Windows.Forms.TextBox Loginbox;
        private System.Windows.Forms.TextBox paswordBox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button EnterButon;
        private System.Windows.Forms.Button LoginFormButtonReg;
    }
}