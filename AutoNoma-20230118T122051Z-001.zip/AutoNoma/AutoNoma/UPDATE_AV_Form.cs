﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoNoma
{
    public partial class UPDATE_AV_Form : Form
    {
        public UPDATE_AV_Form()
        {
            InitializeComponent();
        }
        private SqlConnection SqlConnection = null;
        private void UPDATE_AV_Form_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["KeyDB"].ConnectionString);//PODKLUCENIJE K DB
            SqlConnection.Open();
           
            SqlDataAdapter dataAdapter = new SqlDataAdapter
          ("select * from AtrasanasVieta", SqlConnection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            dataGridView1.DataSource = dataSet.Tables[0];
        }

        private void BACK_Button_Update_Auto_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminVietas_Form vietas_Form = new AdminVietas_Form();
            vietas_Form.Show();
        }

        private void pictureBox_Clear_Click(object sender, EventArgs e)
        {
            textBox_AV.Clear();
            textBox_Numurs.Clear();
            textBox_Zimols.Clear();
        }

        private void pictureBox_Refresh_Click(object sender, EventArgs e)
        {
            this.Hide();
            UPDATE_AV_Form uPDATE_AV_ = new UPDATE_AV_Form();
            uPDATE_AV_.Show();
        }

        private void UPDATE_Button_Auto_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedRowIndex = dataGridView1.CurrentCell.RowIndex;
                var Numurs = textBox_Numurs.Text;
                var Zimols = textBox_Zimols.Text;
                var AV = textBox_AV.Text;
            


              if (dataGridView1.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
              {
               
                    dataGridView1.Rows[selectedRowIndex].SetValues(Numurs, Zimols, AV );
                    var changeQuery = $"update Automobili set A_Zimols='{Zimols}',A_Numurs='{Numurs}',AV_Vieta='{AV}' where A_Numurs='{Numurs}'";
                    var command = new SqlCommand(changeQuery, SqlConnection);
                    command.ExecuteNonQuery();
                
             
              }
            }
            catch (Exception)
            {

                MessageBox.Show("ERROR");    
            }
           
        }
    }
}
