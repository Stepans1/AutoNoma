﻿CREATE TABLE [dbo].[Automobili] (
    [A_Numurs]    VARCHAR (50)   NOT NULL,
    [K_ID]        INT            NULL,
    [A_Zimols]    VARCHAR (50)   NULL,
    [A_Modelis]   VARCHAR (50)   NULL,
    [A_CenaPar1H] INT NULL,
    [A_IresLaiks] INT NULL,
    [A_Img]       IMAGE          NULL,
    PRIMARY KEY CLUSTERED ([A_Numurs] ASC),
    FOREIGN KEY ([K_ID]) REFERENCES [dbo].[Klients] ([K_ID])
);

